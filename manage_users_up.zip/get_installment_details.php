<?php
require 'connectDB.php';

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    if (isset($_GET['selectedPlan']) && !empty($_GET['selectedPlan'])) {
        $selectedPlan = mysqli_real_escape_string($conn, $_GET['selectedPlan']);

        $sql = "SELECT initial_payment, next_installment_amount,next_installment_days FROM payment_plans WHERE installment_plan = ?";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $selectedPlan);
        $stmt->execute();
        
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $initialAmount = $row["initial_payment"];
            $nextInstallmentAmount = $row["next_installment_amount"];
            $nextInstallmentDays = $row["next_installment_days"];


            $response = array(
                'success' => true,
                'initialAmount' => $initialAmount,
                'nextInstallmentAmount' => $nextInstallmentAmount,
                'nextInstallmentDays' => $nextInstallmentDays  


            );

            header('Content-Type: application/json');
            echo json_encode($response);
        } else {
            $response = array('success' => false);
            header('Content-Type: application/json');
            echo json_encode($response);
        }
        $stmt->close(); 
    } else {
        $response = array('success' => false, 'message' => 'No selectedPlan parameter or empty value');
        header('Content-Type: application/json');
        echo json_encode($response);
    }
} else {
    $response = array('success' => false, 'message' => 'Invalid request method');
    header('Content-Type: application/json');
    echo json_encode($response);
}
?>
