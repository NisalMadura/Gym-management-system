<?php
require 'connectDB.php';

$folderPath = './capture_images/';



if (isset($_FILES['image']) && isset($_POST['user_id'])) {
    $image_tmp_name = $_FILES['image']['tmp_name'];
    $image_name = $_FILES['image']['name'];
    $file_extension = strtolower(pathinfo($image_name, PATHINFO_EXTENSION));
    
    $user_id = $_POST['user_id']; 
    
    
    $file_path = $folderPath . $user_id . '.' . $file_extension;

  
    
    $allowed_extensions = array('jpg', 'jpeg', 'png');
    if (in_array($file_extension, $allowed_extensions)) {
        if (move_uploaded_file($image_tmp_name, $file_path)) {
            
            // Insert image info into the database

            $sql = "INSERT INTO users_photo (user_id, photo) VALUES ('$user_id', '$file_path')";

            if ($conn->query($sql) === TRUE) {
                echo json_encode(["Image uploaded successfully."]);
            } else {
                echo json_encode(["Failed to upload image to the database."]);
            }
        } else {
            echo json_encode(["Failed to upload image."]);
        }
    } else {
        echo json_encode(["Invalid file format. Only JPG, JPEG, and PNG are allowed."]);
    }
} else {
    echo json_encode(["No image data received or user ID not provided."]);
}
?>
