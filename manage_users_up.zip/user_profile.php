<?php
error_reporting(0);
ob_start();
session_start();


if (!isset($_SESSION['AdminId']) || !isset($_SESSION['FirstName'])) {

    header("Location: admin_login.php");
    exit(); 
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Profile</title>
    <!-- Include necessary CSS and scripts -->
    <link rel="stylesheet" type="text/css" href="css/userprofile.css">
    <script src="https://code.jquery.com/jquery-3.3.1.js" integrity="sha1256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
    <!-- Your custom script -->
    <script>
        $(window).on("load resize ", function() {
            var scrollWidth = $('.tbl-content').width() - $('.tbl-content table').width();
            $('.tbl-header').css({'padding-right':scrollWidth});
        }).resize();

        // Add your form validation or other scripts here
        function validateForm() {
            // Your validation logic here
            return true; // Return true if the form is valid
        }
    </script>
<style>.modern-input {
    padding: 8px;
    border: 2px solid #ccc;
    border-radius: 4px;
    font-size: 16px;
    width: 150px; 
    margin-bottom: 10px;
}
.modern-button {
    display: inline-block;
    padding: 10px 20px;
    font-size: 16px;
    border: none;
    border-radius: 5px;
    background-color: #4CAF50; /* Change to desired button color */
    color: white;
    text-align: center;
    text-decoration: none;
    transition: background-color 0.3s;
    cursor: pointer;
}



</style>



</head>

<body style="background-image: url('images/pic4.jpg'); background-size: cover; background-position: center;">

    <!-- Include your header content -->
    <?php include 'header.php'; ?>
    <?php  
    require 'connectDB.php';

    
        
        $userDataQuery = "SELECT u.id, u.username, ph.photo
        FROM users u
       
        LEFT JOIN users_photo ph ON u.id = ph.user_id";

        $userDataResult = $conn->query($userDataQuery);
    
        $paymentsQuery = "SELECT u.id, p.start_date, p.expiry_date, p.package 
        FROM users u
        LEFT JOIN payments p ON u.id = p.user_id";
        $paymentsResult = $conn->query($paymentsQuery);

    
    
    ?>

    <main>
        <h1 class="slideInDown animated">User Profile</h1>
<br>
<div class="row">
    <div class="col-lg-6"align="center">
        <label for="user_id" class="user-label" style="font-size: 16px; color: white; font-weight: bold;">Select User ID:</label>
        <div id="memberSelectBoxes" class="select-box user-dropdown"></div> 
        
    </div><br><br><br>
    <div class="col-lg-3" align="center">        
          
                <label for="startDate" style="font-size: 16px; color: white; font-weight: bold;">From:</label>
                <input type="date" id="startDate" name="startDate"  class="modern-input">
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <label for="endDate" style="font-size: 16px; color: white; font-weight: bold;">To:</label>
                <input type="date" id="endDate" name="endDate" class="modern-input"><br><br> 
                <input type="submit" value="Search" class="modern-button">
            </div>
            


<br><br><br>
        <!-- User Data Table -->
        <div class="tbl-header">
            <table cellpadding="" cellspacing="0" border="0">
                <thead>
                    <tr>
                        <th>Profile Picture</th>
                        <th>User ID</th>
                        <th>User Name</th>
                        
                        <th>Start Date</th>
                        <th>Expire Date</th>
                        <th>Package Name</th>
                        
                        <th>Action</th>
                    </tr>
                </thead>
            </table>
        </div>
        <div class="tbl-content">
        <table cellpadding="0" cellspacing="0" border="0">
        <tbody>
        <?php
    while ($userRow = $userDataResult->fetch_assoc()) {
        // Fetching corresponding payment row separately
        $paymentRow = $paymentsResult->fetch_assoc(); // Assuming you've fetched payment data separately

        ?>
        <tr>
            <?php
            // Fetching user-specific image path
            $imagePath = $userRow['photo']; // Use the correct column name from your database

            // Check if the image path exists and display the image accordingly
            if (file_exists($imagePath)) {
                ?>
                <td>
                <img src="<?php echo $imagePath; ?>" alt="Profile Picture" style="width: 50px; height: 50px; border-radius: 50%;">
                </td>
                <?php
            } else {
                // Display a placeholder if the image doesn't exist
                ?>
                <td><img src="path_to_placeholder_image.jpg" alt="No Image" style="width: 50px; height: 50px;"></td>
                <?php
            }
            ?>

            <!-- Display other user-related data -->
            <td><?php echo $userRow['id']; ?></td>
            <td><?php echo $userRow['username']; ?></td>
           

            <!-- Display payment-related data -->
            <td><?php echo $paymentRow['start_date']; ?></td>
            <td><?php echo $paymentRow['expiry_date']; ?></td>
            <td><?php echo $paymentRow['package']; ?></td>
            <td><button onclick="viewUser(<?php echo $userRow['id']; ?>)" class="modern-button">View</button></td>
        </tr>
    <?php
    }
    ?>

</tbody>

        </table>
    </div>
    </main>
    <script>
$(document).ready(function() {
    createDropdown();
  });

function createDropdown() {
    var selectUserDropdown = $("<select></select>");
    selectUserDropdown.attr("name", "member_user_id[]");
    selectUserDropdown.addClass("js-example-basic-single form-control"); 
    selectUserDropdown.attr("title", "Choose a user");
    selectUserDropdown.css("width", "40%");

    $("#memberSelectBoxes").append(selectUserDropdown);

    selectUserDropdown.select2({
      placeholder: 'Select User ID with Name',
      minimumInputLength: 2,
      ajax: {
        url: 'fetchUsernames.php',
        dataType: 'json',
        delay: 250,
        data: function (params) {
          return {
            username: params.term 
          };
        },
        processResults: function(data) {
          var results = data.map(function(user) {
            return { id: user.id, text: user.id + ' - ' + user.username };
          });

          return {
            results: results
          };
        },
        cache: true
      }
    });
  }
 
function viewUser(userID) {
    // Use JavaScript to redirect to the next page with the user ID as a query parameter
    window.location.href = 'weight.php?selectedUserID=' + userID;
}



        </script>
</body>
</html>
